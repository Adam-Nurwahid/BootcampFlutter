package com.adam.shopeasy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
